Use Python to take a screenshot of the active window.

```python
import pyautogui

screenshot = pyautogui.screenshot()
screenshot.save(r"[TARGET.PATH]")
```


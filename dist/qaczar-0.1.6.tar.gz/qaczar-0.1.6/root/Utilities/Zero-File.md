Remove all contents from the target.

```python
with open(r'[TARGET.PATH]', 'w') as f: 
    f.write('')
```
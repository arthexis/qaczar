```python
array = []
array.append("[INPUT]")
print(array[0])
```
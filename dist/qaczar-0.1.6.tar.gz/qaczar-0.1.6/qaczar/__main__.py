# Entry point for qaczar package

from .cli import main

if __name__ == "__main__":
    main()

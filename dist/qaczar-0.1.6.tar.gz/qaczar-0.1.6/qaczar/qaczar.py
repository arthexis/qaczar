# QACZAR is a tool that makes diagrams and texts executable and testable.
# Author: R. J. Guillén Osorio.

# This file is for new ideas, once they are mature enough, they will be moved to the main code.




